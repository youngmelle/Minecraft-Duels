package me.realized.duels.util;

public interface Reloadable {}
