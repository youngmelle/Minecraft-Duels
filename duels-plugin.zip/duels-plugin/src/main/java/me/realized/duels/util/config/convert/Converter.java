package me.realized.duels.util.config.convert;

import java.util.Map;

public interface Converter {

    Map<String, String> renamedKeys();
}
